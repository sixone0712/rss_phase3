export const WEEKS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export const DAY_FORMAT = 'MMMM, YYYY';
export const CONFIRM_BUTTON_TEXT = 'Confirm';
export const START_DATE_TEXT = 'Start Date:';
export const END_DATE_TEXT = 'End Date:';
export const CUSTOM_BUTTON_TEXT = 'Custom';