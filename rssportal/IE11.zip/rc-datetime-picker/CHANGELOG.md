## v1.4.3
> Mar 22, 2017

- **Breaking** Change props name `buttons` to `shortcuts`