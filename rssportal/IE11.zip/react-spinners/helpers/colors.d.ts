declare type RgbaFunction = (color: string, opacity: number) => string;
export declare const calculateRgba: RgbaFunction;
export {};
