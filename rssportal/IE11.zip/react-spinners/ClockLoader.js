"use strict";
var __makeTemplateObject = (this && this.__makeTemplateObject) || function (cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
/** @jsx jsx */
var React = __importStar(require("react"));
var core_1 = require("@emotion/core");
var helpers_1 = require("./helpers");
var rotate = core_1.keyframes(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n  100% { transform: rotate(360deg) }\n"], ["\n  100% { transform: rotate(360deg) }\n"])));
var Loader = /** @class */ (function (_super) {
    __extends(Loader, _super);
    function Loader() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.wrapper = function () {
            var _a = _this.props, size = _a.size, color = _a.color;
            var _b = helpers_1.parseLengthAndUnit(size), value = _b.value, unit = _b.unit;
            return core_1.css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n      position: relative;\n      width: ", ";\n      height: ", ";\n      background-color: transparent;\n      box-shadow: inset 0px 0px 0px 2px ", ";\n      border-radius: 50%;\n\n      &:after,\n      &:before {\n        position: absolute;\n        content: \"\";\n        background-color: ", ";\n      }\n\n      &:after {\n        width: ", "px;\n        height: 2px;\n        top: ", "px;\n        left: ", "px;\n        transform-origin: 1px 1px;\n        animation: ", " 2s linear infinite;\n      }\n\n      &:before {\n        width: ", "px;\n        height: 2px;\n        top: ", "px;\n        left: ", "px;\n        transform-origin: 1px 1px;\n        animation: ", " 8s linear infinite;\n      }\n    "], ["\n      position: relative;\n      width: ", ";\n      height: ", ";\n      background-color: transparent;\n      box-shadow: inset 0px 0px 0px 2px ", ";\n      border-radius: 50%;\n\n      &:after,\n      &:before {\n        position: absolute;\n        content: \"\";\n        background-color: ", ";\n      }\n\n      &:after {\n        width: ", "px;\n        height: 2px;\n        top: ", "px;\n        left: ", "px;\n        transform-origin: 1px 1px;\n        animation: ", " 2s linear infinite;\n      }\n\n      &:before {\n        width: ", "px;\n        height: 2px;\n        top: ", "px;\n        left: ", "px;\n        transform-origin: 1px 1px;\n        animation: ", " 8s linear infinite;\n      }\n    "])), "" + value + unit, "" + value + unit, color, color, value / 2.4, value / 2 - 1, value / 2 - 1, rotate, value / 3, value / 2 - 1, value / 2 - 1, rotate);
        };
        return _this;
    }
    Loader.prototype.render = function () {
        var _a = this.props, loading = _a.loading, css = _a.css;
        return loading ? core_1.jsx("div", { css: [this.wrapper(), css] }) : null;
    };
    Loader.defaultProps = helpers_1.sizeDefaults(50);
    return Loader;
}(React.PureComponent));
exports.default = Loader;
var templateObject_1, templateObject_2;
