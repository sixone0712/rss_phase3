"use strict";
var __makeTemplateObject = (this && this.__makeTemplateObject) || function (cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
/** @jsx jsx */
var React = __importStar(require("react"));
var core_1 = require("@emotion/core");
var helpers_1 = require("./helpers");
// 1.5 4.5 7.5
var distance = [1, 3, 5];
var propagate = [
    core_1.keyframes(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n      25% {transform: translateX(-", "rem) scale(0.75)}\n      50% {transform: translateX(-", "rem) scale(0.6)}\n      75% {transform: translateX(-", "rem) scale(0.5)}\n      95% {transform: translateX(0rem) scale(1)}\n    "], ["\n      25% {transform: translateX(-", "rem) scale(0.75)}\n      50% {transform: translateX(-", "rem) scale(0.6)}\n      75% {transform: translateX(-", "rem) scale(0.5)}\n      95% {transform: translateX(0rem) scale(1)}\n    "])), distance[0], distance[1], distance[2]),
    core_1.keyframes(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n      25% {transform: translateX(-", "rem) scale(0.75)}\n      50% {transform: translateX(-", "rem) scale(0.6)}\n      75% {transform: translateX(-", "rem) scale(0.6)}\n      95% {transform: translateX(0rem) scale(1)}\n    "], ["\n      25% {transform: translateX(-", "rem) scale(0.75)}\n      50% {transform: translateX(-", "rem) scale(0.6)}\n      75% {transform: translateX(-", "rem) scale(0.6)}\n      95% {transform: translateX(0rem) scale(1)}\n    "])), distance[0], distance[1], distance[1]),
    core_1.keyframes(templateObject_3 || (templateObject_3 = __makeTemplateObject(["\n      25% {transform: translateX(-", "rem) scale(0.75)}\n      75% {transform: translateX(-", "rem) scale(0.75)}\n      95% {transform: translateX(0rem) scale(1)}\n    "], ["\n      25% {transform: translateX(-", "rem) scale(0.75)}\n      75% {transform: translateX(-", "rem) scale(0.75)}\n      95% {transform: translateX(0rem) scale(1)}\n    "])), distance[0], distance[0]),
    core_1.keyframes(templateObject_4 || (templateObject_4 = __makeTemplateObject(["\n      25% {transform: translateX(", "rem) scale(0.75)}\n      75% {transform: translateX(", "rem) scale(0.75)}\n      95% {transform: translateX(0rem) scale(1)}\n    "], ["\n      25% {transform: translateX(", "rem) scale(0.75)}\n      75% {transform: translateX(", "rem) scale(0.75)}\n      95% {transform: translateX(0rem) scale(1)}\n    "])), distance[0], distance[0]),
    core_1.keyframes(templateObject_5 || (templateObject_5 = __makeTemplateObject(["\n      25% {transform: translateX(", "rem) scale(0.75)}\n      50% {transform: translateX(", "rem) scale(0.6)}\n      75% {transform: translateX(", "rem) scale(0.6)}\n      95% {transform: translateX(0rem) scale(1)}\n    "], ["\n      25% {transform: translateX(", "rem) scale(0.75)}\n      50% {transform: translateX(", "rem) scale(0.6)}\n      75% {transform: translateX(", "rem) scale(0.6)}\n      95% {transform: translateX(0rem) scale(1)}\n    "])), distance[0], distance[1], distance[1]),
    core_1.keyframes(templateObject_6 || (templateObject_6 = __makeTemplateObject(["\n      25% {transform: translateX(", "rem) scale(0.75)}\n      50% {transform: translateX(", "rem) scale(0.6)}\n      75% {transform: translateX(", "rem) scale(0.5)}\n      95% {transform: translateX(0rem) scale(1)}\n    "], ["\n      25% {transform: translateX(", "rem) scale(0.75)}\n      50% {transform: translateX(", "rem) scale(0.6)}\n      75% {transform: translateX(", "rem) scale(0.5)}\n      95% {transform: translateX(0rem) scale(1)}\n    "])), distance[0], distance[1], distance[2])
];
var Loader = /** @class */ (function (_super) {
    __extends(Loader, _super);
    function Loader() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.style = function (i) {
            var _a = _this.props, size = _a.size, color = _a.color;
            var _b = helpers_1.parseLengthAndUnit(size), value = _b.value, unit = _b.unit;
            return core_1.css(templateObject_7 || (templateObject_7 = __makeTemplateObject(["\n      position: absolute;\n      font-size: ", ";\n      width: ", ";\n      height: ", ";\n      background: ", ";\n      border-radius: 50%;\n      animation: ", " 1.5s infinite;\n      animation-fill-mode: forwards;\n    "], ["\n      position: absolute;\n      font-size: ", ";\n      width: ", ";\n      height: ", ";\n      background: ", ";\n      border-radius: 50%;\n      animation: ", " 1.5s infinite;\n      animation-fill-mode: forwards;\n    "])), "" + value / 3 + unit, "" + value + unit, "" + value + unit, color, propagate[i]);
        };
        _this.wrapper = function () {
            return core_1.css(templateObject_8 || (templateObject_8 = __makeTemplateObject(["\n      position: relative;\n    "], ["\n      position: relative;\n    "])));
        };
        return _this;
    }
    Loader.prototype.render = function () {
        var _a = this.props, loading = _a.loading, css = _a.css;
        return loading ? (core_1.jsx("div", { css: [this.wrapper(), css] },
            core_1.jsx("div", { css: this.style(0) }),
            core_1.jsx("div", { css: this.style(1) }),
            core_1.jsx("div", { css: this.style(2) }),
            core_1.jsx("div", { css: this.style(3) }),
            core_1.jsx("div", { css: this.style(4) }),
            core_1.jsx("div", { css: this.style(5) }))) : null;
    };
    Loader.defaultProps = helpers_1.sizeDefaults(15);
    return Loader;
}(React.PureComponent));
exports.default = Loader;
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7, templateObject_8;
